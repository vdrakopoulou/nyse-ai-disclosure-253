from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
from urllib.parse import urlparse

import numpy as np
import pandas as pd
import yaml
from scipy.stats import beta


class ReplicationError(Exception):
    """Raised when the replication package encounters a fatal validation error."""


def read_yaml(path: Path) -> dict[str, Any]:
    """Read a YAML configuration file."""
    if not path.exists():
        raise ReplicationError(f"Config file not found: {path}")
    with path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle)
    if not isinstance(data, dict):
        raise ReplicationError(f"Expected YAML mapping at {path}")
    return data


def ensure_dir(path: Path) -> None:
    """Create a directory if it does not already exist."""
    path.mkdir(parents=True, exist_ok=True)


def ensure_dirs(paths: Iterable[Path]) -> None:
    """Create multiple directories."""
    for path in paths:
        ensure_dir(path)


def setup_logging(log_dir: Path, logger_name: str = "replication") -> logging.Logger:
    """Configure a deterministic console and file logger."""
    ensure_dir(log_dir)
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = logging.FileHandler(log_dir / "run_all.log", encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    return logger


def validate_columns(df: pd.DataFrame, required: Sequence[str], dataset_name: str) -> None:
    """Raise a helpful error if required columns are missing."""
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ReplicationError(
            f"Dataset '{dataset_name}' is missing required columns: {missing}. "
            f"Available columns: {list(df.columns)}"
        )


def assert_unique(df: pd.DataFrame, columns: Sequence[str], dataset_name: str) -> None:
    """Validate one-to-one keys for a dataframe."""
    duplicate_mask = df.duplicated(list(columns), keep=False)
    if duplicate_mask.any():
        preview = df.loc[duplicate_mask, list(columns)].head(10).to_dict(orient="records")
        raise ReplicationError(
            f"Dataset '{dataset_name}' must be unique on {list(columns)}. "
            f"Example duplicates: {preview}"
        )


def normalize_text(value: Any) -> str:
    """Normalize text for stable comparison without changing substantive wording."""
    if pd.isna(value):
        return ""
    text = str(value)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def normalize_key(value: Any) -> str:
    """Normalize identifiers such as company names or statuses."""
    return normalize_text(value).casefold()


def extract_domain(url: Any) -> str:
    """Extract the lowercase network location from a URL."""
    text = normalize_text(url)
    if not text:
        return ""
    try:
        return urlparse(text).netloc.lower()
    except ValueError:
        return ""


def ordered_regex_match(text: str, rules: Sequence[Mapping[str, str]], default: str) -> str:
    """Apply ordered regex rules and return the first matching label."""
    for rule in rules:
        pattern = rule["pattern"]
        label = rule["label"]
        if re.search(pattern, text):
            return label
    return default


def compute_channel_hhi(counts: Sequence[int | float]) -> float:
    """Compute a Herfindahl-style concentration index from a sequence of counts."""
    array = np.asarray(list(counts), dtype=float)
    total = array.sum()
    if total <= 0:
        return float("nan")
    shares = array / total
    return float(np.square(shares).sum())


def clopper_pearson_interval(successes: int, trials: int, alpha: float = 0.05) -> tuple[float, float]:
    """Exact Clopper-Pearson interval for a binomial proportion."""
    if trials <= 0:
        raise ReplicationError("Trials must be positive for an exact binomial interval.")
    if successes < 0 or successes > trials:
        raise ReplicationError("Successes must lie between 0 and trials.")

    lower = 0.0 if successes == 0 else float(beta.ppf(alpha / 2, successes, trials - successes + 1))
    upper = 1.0 if successes == trials else float(beta.ppf(1 - alpha / 2, successes + 1, trials - successes))
    return lower, upper


def clopper_pearson_upper(successes: int, trials: int, alpha: float = 0.05) -> float:
    """One-sided exact upper bound for a binomial proportion."""
    if trials <= 0:
        raise ReplicationError("Trials must be positive for an exact binomial interval.")
    if successes < 0 or successes > trials:
        raise ReplicationError("Successes must lie between 0 and trials.")
    if successes == trials:
        return 1.0
    return float(beta.ppf(1 - alpha, successes + 1, trials - successes))


def gwet_ac1(coder_a: Sequence[Any], coder_b: Sequence[Any], labels: Sequence[Any] | None = None) -> float:
    """Compute Gwet's AC1 for nominal categories without external dependencies."""
    a = pd.Series(list(coder_a))
    b = pd.Series(list(coder_b))
    if len(a) != len(b):
        raise ReplicationError("AC1 requires coder vectors of equal length.")
    if len(a) == 0:
        raise ReplicationError("AC1 cannot be computed on an empty comparison set.")

    if labels is None:
        labels = sorted(set(a.dropna()).union(set(b.dropna())))
    labels = list(labels)
    if len(labels) == 1:
        return 1.0

    observed = float((a == b).mean())
    p_a = a.value_counts(normalize=True).reindex(labels, fill_value=0.0)
    p_b = b.value_counts(normalize=True).reindex(labels, fill_value=0.0)
    p_bar = (p_a + p_b) / 2
    chance = float((p_bar * (1 - p_bar)).sum() / (len(labels) - 1))

    if np.isclose(1 - chance, 0.0):
        return float("nan")
    return float((observed - chance) / (1 - chance))


def write_json(data: Mapping[str, Any], path: Path) -> None:
    """Write JSON with stable formatting."""
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)


def coerce_bool(series: pd.Series) -> pd.Series:
    """Safely convert common truthy or falsy values to booleans."""
    mapping = {
        "true": True,
        "false": False,
        "yes": True,
        "no": False,
        "1": True,
        "0": False,
    }
    if series.dtype == bool:
        return series
    lowered = series.astype(str).str.strip().str.casefold()
    if not lowered.isin(mapping).all():
        invalid = lowered.loc[~lowered.isin(mapping)].unique().tolist()
        raise ReplicationError(f"Cannot coerce values to boolean: {invalid}")
    return lowered.map(mapping)
