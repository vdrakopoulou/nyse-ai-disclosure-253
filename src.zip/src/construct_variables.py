from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.utils import compute_channel_hhi, normalize_text, ordered_regex_match


def categorize_employment_channel(source_type: str, config: dict[str, Any]) -> str:
    """Map employment-file source types to broad analytic channels."""
    mapping = {
        key.casefold(): value
        for key, value in config["analysis"]["employment_channel_map"].items()
    }
    key = normalize_text(source_type).casefold()
    return mapping.get(key, "other_public_materials")


def categorize_direct_channel(source_type: str, source_title: str, source_url: str, config: dict[str, Any]) -> str:
    """Map direct-evidence source metadata to broad analytic channels."""
    text = " | ".join([normalize_text(source_type), normalize_text(source_title), normalize_text(source_url)])
    rules = config["analysis"]["direct_channel_rules"]
    return ordered_regex_match(text, rules, default="other_public_materials")


def contains_pattern(text: str, pattern: str) -> bool:
    """Return a boolean regex match on normalized text."""
    return bool(re.search(pattern, normalize_text(text)))


def flag_oci(sentence: str, config: dict[str, Any]) -> bool:
    """Operationalize the Outcome Claims Index at the sentence level."""
    text = normalize_text(sentence)
    if not text:
        return False
    ai_match = contains_pattern(text, config["analysis"]["ai_regex"]) or contains_pattern(text, config["analysis"]["python_regex"])
    outcome_match = contains_pattern(text, config["analysis"]["oci_outcome_regex"])
    quant_match = contains_pattern(text, config["analysis"]["oci_quant_regex"])
    claim_match = contains_pattern(text, config["analysis"]["oci_claim_verb_regex"])
    return bool(ai_match and outcome_match and quant_match and claim_match)


def _library_pattern(term: str) -> str:
    escaped = re.escape(term)
    return rf"(?i)\b{escaped}\b"


def match_named_libraries(sentence_id: str, sentence_text: str, ticker: str, company_name: str, broad_channel: str, config: dict[str, Any]) -> list[dict[str, str]]:
    """Identify dictionary-based technical naming matches with a conservative context filter."""
    text = normalize_text(sentence_text)
    if not text:
        return []
    context_ok = contains_pattern(text, config["analysis"]["library_context_regex"]) or contains_pattern(text, config["analysis"]["python_regex"])
    if not context_ok:
        return []

    seen: set[tuple[str, str]] = set()
    matches: list[dict[str, str]] = []
    for library_name, dimension in config["analysis"]["library_dictionary"].items():
        if re.search(_library_pattern(library_name), text):
            key = (library_name, dimension)
            if key in seen:
                continue
            seen.add(key)
            matches.append(
                {
                    "sentence_id": sentence_id,
                    "ticker": ticker,
                    "company_name": company_name,
                    "broad_channel": broad_channel,
                    "library_name": library_name,
                    "dimension": dimension,
                }
            )
    return matches


def _base_sentence_columns(df: pd.DataFrame) -> list[str]:
    columns = [
        "sentence_id",
        "ticker",
        "company_name",
        "source_row_number",
        "current_security_name",
        "broad_subsector",
        "dataset_name",
        "broad_channel",
        "source_type",
        "source_title",
        "source_url",
        "host_type",
        "capture_method",
        "ref_id",
        "sentence_text",
    ]
    missing = [column for column in columns if column not in df.columns]
    if missing:
        raise ValueError(f"Sentence corpus is missing expected columns: {missing}")
    return columns


def build_sentence_corpus(cleaned: dict[str, pd.DataFrame], config: dict[str, Any]) -> dict[str, pd.DataFrame]:
    """Construct the main sentence-level corpus used for descriptive analysis."""
    issuer_master = cleaned["issuer_included"][["ticker", "source_row_number", "current_security_name"]].copy()

    employment = cleaned["employment_materials"].merge(issuer_master, on="ticker", how="left", validate="one_to_one")
    employment["dataset_name"] = "employment_materials_package"
    employment["broad_channel"] = employment["source_type"].apply(lambda value: categorize_employment_channel(value, config))
    employment["source_title"] = ""
    employment["host_type"] = ""
    employment["sentence_id"] = employment["ticker"].apply(lambda ticker: f"employment__{ticker}")
    employment = employment[
        [
            "sentence_id",
            "ticker",
            "company_name",
            "source_row_number",
            "current_security_name",
            "broad_subsector",
            "dataset_name",
            "broad_channel",
            "source_type",
            "source_title",
            "source_url",
            "host_type",
            "capture_method",
            "ref_id",
            "sentence_text",
        ]
    ]

    direct = cleaned["direct_primary"].copy()
    direct = direct.loc[direct["has_sentence"]].copy()
    direct["dataset_name"] = "direct_company_package"
    direct["broad_channel"] = direct.apply(
        lambda row: categorize_direct_channel(row["source_type"], row["source_title"], row["source_url"], config),
        axis=1,
    )
    direct["capture_method"] = ""
    direct["ref_id"] = ""
    direct["sentence_id"] = direct["source_row_number"].apply(lambda row_number: f"direct__{row_number}")
    direct = direct[
        [
            "sentence_id",
            "ticker",
            "company_name",
            "source_row_number",
            "current_security_name",
            "broad_subsector",
            "dataset_name",
            "broad_channel",
            "source_type",
            "source_title",
            "source_url",
            "host_type",
            "capture_method",
            "ref_id",
            "sentence_text",
        ]
    ]

    corpus = pd.concat([employment, direct], ignore_index=True)
    _base_sentence_columns(corpus)

    corpus["sentence_text"] = corpus["sentence_text"].map(normalize_text)
    corpus["has_python"] = corpus["sentence_text"].apply(lambda text: contains_pattern(text, config["analysis"]["python_regex"]))
    corpus["has_ai_signal"] = corpus["sentence_text"].apply(lambda text: contains_pattern(text, config["analysis"]["ai_regex"]))
    corpus["oci_flag"] = corpus["sentence_text"].apply(lambda text: flag_oci(text, config))

    library_rows: list[dict[str, str]] = []
    for row in corpus.itertuples(index=False):
        library_rows.extend(
            match_named_libraries(
                sentence_id=row.sentence_id,
                sentence_text=row.sentence_text,
                ticker=row.ticker,
                company_name=row.company_name,
                broad_channel=row.broad_channel,
                config=config,
            )
        )

    library_matches = pd.DataFrame(
        library_rows,
        columns=["sentence_id", "ticker", "company_name", "broad_channel", "library_name", "dimension"],
    )
    if library_matches.empty:
        library_matches = pd.DataFrame(
            columns=["sentence_id", "ticker", "company_name", "broad_channel", "library_name", "dimension"]
        )

    sentence_library_summary = (
        library_matches.groupby("sentence_id")
        .agg(
            library_match_count=("library_name", "size"),
            unique_library_count=("library_name", pd.Series.nunique),
            unique_dimension_count=("dimension", pd.Series.nunique),
            library_list=("library_name", lambda values: "|".join(sorted(set(values)))),
            dimension_list=("dimension", lambda values: "|".join(sorted(set(values)))),
        )
        .reset_index()
        if not library_matches.empty
        else pd.DataFrame(
            columns=[
                "sentence_id",
                "library_match_count",
                "unique_library_count",
                "unique_dimension_count",
                "library_list",
                "dimension_list",
            ]
        )
    )

    corpus = corpus.merge(sentence_library_summary, on="sentence_id", how="left")
    fill_zero_columns = ["library_match_count", "unique_library_count", "unique_dimension_count"]
    for column in fill_zero_columns:
        corpus[column] = corpus[column].fillna(0).astype(int)
    for column in ["library_list", "dimension_list"]:
        corpus[column] = corpus[column].fillna("")

    oci_candidates = corpus.loc[corpus["oci_flag"]].copy()

    return {
        "sentence_corpus": corpus,
        "library_matches": library_matches,
        "oci_candidates": oci_candidates,
    }


def build_firm_level_dataset(cleaned: dict[str, pd.DataFrame], sentence_corpus: pd.DataFrame, library_matches: pd.DataFrame) -> pd.DataFrame:
    """Aggregate sentence-level evidence into firm-level disclosure measures."""
    issuer_master = cleaned["issuer_included"].copy()
    base = issuer_master[
        [
            "source_row_number",
            "ticker",
            "company_name",
            "current_security_name",
            "broad_subsector",
            "decision",
            "primary_reason",
        ]
    ].copy()

    sentence_counts = sentence_corpus.groupby("ticker").size().rename("disclosure_intensity_sentences")
    visibility = sentence_counts.gt(0).rename("public_visibility")
    python_flags = sentence_corpus.groupby("ticker")["has_python"].max().rename("explicit_python_flag")
    oci_flags = sentence_corpus.groupby("ticker")["oci_flag"].max().rename("any_oci_claim")
    oci_counts = sentence_corpus.groupby("ticker")["oci_flag"].sum().rename("oci_sentence_count")
    channel_counts = sentence_corpus.groupby(["ticker", "broad_channel"]).size().rename("sentence_count").reset_index()
    distinct_channels = channel_counts.groupby("ticker")["broad_channel"].nunique().rename("distinct_broad_channels")
    channel_hhi = channel_counts.groupby("ticker")["sentence_count"].apply(lambda values: compute_channel_hhi(values.tolist())).rename("channel_hhi")

    library_summary = (
        library_matches.groupby("ticker")
        .agg(
            library_match_count_total=("library_name", "size"),
            named_library_count=("library_name", pd.Series.nunique),
            named_dimension_count=("dimension", pd.Series.nunique),
            named_library_list=("library_name", lambda values: "|".join(sorted(set(values)))),
            named_dimension_list=("dimension", lambda values: "|".join(sorted(set(values)))),
        )
        .reset_index()
        if not library_matches.empty
        else pd.DataFrame(
            columns=[
                "ticker",
                "library_match_count_total",
                "named_library_count",
                "named_dimension_count",
                "named_library_list",
                "named_dimension_list",
            ]
        )
    )

    channel_pivot = channel_counts.pivot_table(
        index="ticker",
        columns="broad_channel",
        values="sentence_count",
        aggfunc="sum",
        fill_value=0,
    )
    channel_pivot.columns = [f"sentence_count__{column}" for column in channel_pivot.columns]
    channel_pivot = channel_pivot.reset_index()

    direct_status = cleaned["direct_primary"][["ticker", "direct_status_binary"]].copy()
    employment_status = cleaned["employment_materials"][["ticker", "status"]].rename(columns={"status": "employment_record_status"})

    firm = base.merge(sentence_counts, on="ticker", how="left")
    firm = firm.merge(visibility, on="ticker", how="left")
    firm = firm.merge(python_flags, on="ticker", how="left")
    firm = firm.merge(oci_flags, on="ticker", how="left")
    firm = firm.merge(oci_counts, on="ticker", how="left")
    firm = firm.merge(distinct_channels, on="ticker", how="left")
    firm = firm.merge(channel_hhi, on="ticker", how="left")
    firm = firm.merge(library_summary, on="ticker", how="left")
    firm = firm.merge(channel_pivot, on="ticker", how="left")
    firm = firm.merge(direct_status, on="ticker", how="left")
    firm = firm.merge(employment_status, on="ticker", how="left")

    fill_false = ["public_visibility", "explicit_python_flag", "any_oci_claim"]
    for column in fill_false:
        firm[column] = firm[column].fillna(False).astype(bool)
    fill_zero = [
        "disclosure_intensity_sentences",
        "oci_sentence_count",
        "distinct_broad_channels",
        "library_match_count_total",
        "named_library_count",
        "named_dimension_count",
    ]
    for column in fill_zero:
        firm[column] = firm[column].fillna(0).astype(int)
    text_fill = ["named_library_list", "named_dimension_list"]
    for column in text_fill:
        firm[column] = firm[column].fillna("")

    sentence_count_columns = [column for column in firm.columns if column.startswith("sentence_count__")]
    for column in sentence_count_columns:
        firm[column] = firm[column].fillna(0).astype(int)

    firm["disclosure_state"] = np.select(
        [firm["explicit_python_flag"], firm["public_visibility"]],
        ["explicit_python", "indirect_ai"],
        default="none",
    )

    dominant_channel = channel_counts.sort_values(["ticker", "sentence_count", "broad_channel"], ascending=[True, False, True])
    dominant_channel = dominant_channel.drop_duplicates(subset=["ticker"])[["ticker", "broad_channel"]]
    dominant_channel = dominant_channel.rename(columns={"broad_channel": "dominant_broad_channel"})
    firm = firm.merge(dominant_channel, on="ticker", how="left")
    firm["dominant_broad_channel"] = firm["dominant_broad_channel"].fillna("")

    return firm.sort_values("ticker").reset_index(drop=True)


def construct_all(cleaned: dict[str, pd.DataFrame], config: dict[str, Any]) -> dict[str, pd.DataFrame]:
    """Run all variable-construction steps."""
    sentence_outputs = build_sentence_corpus(cleaned, config)
    firm_level = build_firm_level_dataset(cleaned, sentence_outputs["sentence_corpus"], sentence_outputs["library_matches"])
    return {
        **sentence_outputs,
        "firm_level_dataset": firm_level,
    }
