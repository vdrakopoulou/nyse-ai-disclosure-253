from __future__ import annotations

from typing import Any

import pandas as pd
from sklearn.metrics import cohen_kappa_score

from src.construct_variables import categorize_direct_channel
from src.utils import extract_domain, gwet_ac1, normalize_text


DIRECT_LABELS = ["verified", "unresolved"]


def prepare_direct_coder_merge(cleaned: dict[str, pd.DataFrame], config: dict[str, Any]) -> pd.DataFrame:
    """Merge primary and second-coder direct evidence on the overlapping coded unit."""
    primary = cleaned["direct_primary"].copy()
    second = cleaned["direct_second_coder"].copy()

    primary["primary_broad_channel"] = primary.apply(
        lambda row: categorize_direct_channel(row["source_type"], row["source_title"], row["source_url"], config),
        axis=1,
    )
    second["second_broad_channel"] = second.apply(
        lambda row: categorize_direct_channel(row["source_type"], row["source_title"], row["source_url"], config),
        axis=1,
    )

    merged = primary.merge(
        second,
        on=["source_row_number", "ticker"],
        how="inner",
        validate="one_to_one",
        suffixes=("_primary", "_second"),
    )

    merged["status_agreement"] = merged["direct_status_binary"] == merged["direct_second_status_binary"]
    merged["exact_url_match"] = merged["source_url_primary"].map(normalize_text) == merged["source_url_second"].map(normalize_text)
    merged["exact_sentence_match"] = merged["sentence_text_primary"].map(normalize_text) == merged["sentence_text_second"].map(normalize_text)
    merged["primary_domain"] = merged["source_url_primary"].map(extract_domain)
    merged["second_domain"] = merged["source_url_second"].map(extract_domain)
    merged["same_domain"] = merged["primary_domain"] == merged["second_domain"]
    merged["same_broad_channel"] = merged["primary_broad_channel"] == merged["second_broad_channel"]

    def disagreement_type(row: pd.Series) -> str:
        if not row["status_agreement"]:
            return "status_disagreement"
        if row["direct_status_binary"] == "verified" and not row["exact_url_match"]:
            return "both_verified_source_url_mismatch"
        if row["direct_status_binary"] == "verified" and row["exact_url_match"] and not row["exact_sentence_match"]:
            return "both_verified_sentence_variant"
        return "agreement"

    merged["disagreement_type"] = merged.apply(disagreement_type, axis=1)
    return merged


def summarize_direct_agreement(merged: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Compute direct-evidence reliability metrics and disagreement reporting."""
    confusion = (
        pd.crosstab(
            merged["direct_status_binary"],
            merged["direct_second_status_binary"],
            dropna=False,
        )
        .rename_axis(index="primary_status", columns="second_coder_status")
        .reset_index()
    )

    raw_agreement = float(merged["status_agreement"].mean())
    kappa = float(cohen_kappa_score(merged["direct_status_binary"], merged["direct_second_status_binary"], labels=DIRECT_LABELS))
    ac1 = float(gwet_ac1(merged["direct_status_binary"], merged["direct_second_status_binary"], labels=DIRECT_LABELS))

    both_verified = merged.loc[
        (merged["direct_status_binary"] == "verified") & (merged["direct_second_status_binary"] == "verified")
    ].copy()

    metrics = pd.DataFrame(
        [
            {
                "comparison": "direct_evidence_presence",
                "n_units": int(len(merged)),
                "raw_agreement": raw_agreement,
                "cohen_kappa": kappa,
                "gwet_ac1": ac1,
                "n_status_disagreements": int((~merged["status_agreement"]).sum()),
                "n_both_verified": int(len(both_verified)),
                "both_verified_exact_url_rate": float(both_verified["exact_url_match"].mean()) if len(both_verified) else float("nan"),
                "both_verified_same_domain_rate": float(both_verified["same_domain"].mean()) if len(both_verified) else float("nan"),
                "both_verified_same_broad_channel_rate": float(both_verified["same_broad_channel"].mean()) if len(both_verified) else float("nan"),
                "sentence_exact_match_interpretation": "Primary direct sentences are paraphrased summaries while the second-coder file stores exact or copied evidence sentences; exact sentence agreement is therefore descriptive only.",
            }
        ]
    )

    disagreement_log = merged.loc[
        merged["disagreement_type"].isin(["status_disagreement", "both_verified_source_url_mismatch"])
    ].copy()
    keep_columns = [
        "source_row_number",
        "ticker",
        "company_name_primary",
        "direct_status_binary",
        "direct_second_status_binary",
        "disagreement_type",
        "primary_broad_channel",
        "second_broad_channel",
        "same_broad_channel",
        "primary_domain",
        "second_domain",
        "same_domain",
        "source_type_primary",
        "source_type_second",
        "source_title_primary",
        "source_title_second",
        "source_url_primary",
        "source_url_second",
        "sentence_text_primary",
        "sentence_text_second",
        "notes_primary",
        "notes_second",
    ]
    disagreement_log = disagreement_log[keep_columns].sort_values(["disagreement_type", "ticker"]).reset_index(drop=True)

    return confusion, metrics, disagreement_log


def build_filing_proxy_alignment(cleaned: dict[str, pd.DataFrame], config: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compare second-coder filing verification to a derived primary filing-source indicator.

    This is a proxy alignment check, not a formal intercoder reliability statistic, because no
    primary filing-audit workbook was uploaded.
    """
    primary = cleaned["direct_primary"].copy()
    primary["primary_selected_filing_source"] = primary.apply(
        lambda row: categorize_direct_channel(row["source_type"], row["source_title"], row["source_url"], config) == "filings_formal_reports",
        axis=1,
    )
    proxy = primary[["ticker", "company_name", "source_row_number", "primary_selected_filing_source", "source_type", "source_title", "source_url"]].copy()

    filing_second = cleaned["filing_second_combined"].copy()
    filing_second["filing_second_verified"] = filing_second["filing_second_status_binary"] == "verified"

    merged = proxy.merge(filing_second[["ticker", "filing_second_status_binary", "filing_second_verified"]], on="ticker", how="left", validate="one_to_one")
    merged["proxy_alignment"] = merged["primary_selected_filing_source"] == merged["filing_second_verified"]

    summary = (
        pd.crosstab(
            merged["primary_selected_filing_source"],
            merged["filing_second_verified"],
            dropna=False,
        )
        .rename_axis(index="primary_selected_filing_source", columns="filing_second_verified")
        .reset_index()
    )
    summary["comparison_note"] = "Proxy alignment only; no primary filing-audit file was uploaded, so this table is not an intercoder reliability estimate."
    return merged, summary


def coder_agreement_all(cleaned: dict[str, pd.DataFrame], config: dict[str, Any]) -> dict[str, pd.DataFrame]:
    """Run all coder-agreement and disagreement-reporting steps."""
    direct_merged = prepare_direct_coder_merge(cleaned, config)
    direct_confusion, direct_metrics, direct_disagreement_log = summarize_direct_agreement(direct_merged)
    filing_proxy_merged, filing_proxy_summary = build_filing_proxy_alignment(cleaned, config)
    return {
        "direct_coder_merged": direct_merged,
        "direct_coder_confusion": direct_confusion,
        "direct_coder_metrics": direct_metrics,
        "direct_disagreement_log": direct_disagreement_log,
        "filing_proxy_merged": filing_proxy_merged,
        "filing_proxy_summary": filing_proxy_summary,
    }
