from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from src.utils import ReplicationError


def _resolve(path_root: Path, relative_path: str) -> Path:
    path = path_root / relative_path
    if not path.exists():
        raise ReplicationError(f"Input file not found: {path}")
    return path


def load_raw_data(project_root: Path, config: dict[str, Any]) -> dict[str, pd.DataFrame]:
    """Load all uploaded raw files and required sheets."""
    raw_paths = config["paths"]["raw"]
    sheets = config["sheets"]

    issuer_path = _resolve(project_root, raw_paths["issuer_screening"])
    employment_path = _resolve(project_root, raw_paths["employment_materials"])
    direct_path = _resolve(project_root, raw_paths["direct_company_sentences"])
    direct_second_path = _resolve(project_root, raw_paths["second_coder_direct"])
    filing_second_path = _resolve(project_root, raw_paths["second_coder_filing"])

    raw_data: dict[str, pd.DataFrame] = {
        "issuer_screened": pd.read_excel(issuer_path, sheet_name=sheets["issuer_screening_screened"]),
        "issuer_included": pd.read_excel(issuer_path, sheet_name=sheets["issuer_screening_included"]),
        "issuer_excluded": pd.read_excel(issuer_path, sheet_name=sheets["issuer_screening_excluded"]),
        "issuer_duplicates": pd.read_excel(issuer_path, sheet_name=sheets["issuer_screening_duplicates"]),
        "employment_materials": pd.read_csv(employment_path),
        "direct_primary": pd.read_excel(direct_path, sheet_name=sheets["direct_primary_all_status"]),
        "direct_summary": pd.read_excel(direct_path, sheet_name=sheets["direct_summary"]),
        "direct_readme": pd.read_excel(direct_path, sheet_name=sheets["direct_readme"]),
        "direct_second_verified": pd.read_excel(direct_second_path, sheet_name=sheets["direct_second_verified"]),
        "direct_second_unresolved": pd.read_excel(direct_second_path, sheet_name=sheets["direct_second_unresolved"]),
        "filing_second_verified": pd.read_excel(filing_second_path, sheet_name=sheets["filing_second_verified"]),
        "filing_second_unresolved": pd.read_excel(filing_second_path, sheet_name=sheets["filing_second_unresolved"]),
    }
    return raw_data
