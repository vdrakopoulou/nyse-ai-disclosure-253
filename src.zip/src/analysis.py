from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import pandas as pd

from src.utils import clopper_pearson_interval, clopper_pearson_upper, write_json


def _series_to_table(series: pd.Series, index_name: str, value_name: str) -> pd.DataFrame:
    table = series.rename_axis(index_name).reset_index(name=value_name)
    return table


def _save_bar_figure(data: pd.DataFrame, x: str, y: str, title: str, output_stem: Path) -> None:
    plt.figure(figsize=(8, 5))
    plt.bar(data[x], data[y])
    plt.title(title)
    plt.xlabel(x.replace("_", " ").title())
    plt.ylabel(y.replace("_", " ").title())
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(output_stem.with_suffix(".png"), dpi=200)
    plt.savefig(output_stem.with_suffix(".pdf"))
    plt.close()


def _save_histogram(series: pd.Series, title: str, output_stem: Path) -> None:
    plt.figure(figsize=(8, 5))
    plt.hist(series.dropna())
    plt.title(title)
    plt.xlabel(series.name.replace("_", " ").title())
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(output_stem.with_suffix(".png"), dpi=200)
    plt.savefig(output_stem.with_suffix(".pdf"))
    plt.close()


def create_analysis_outputs(
    cleaned: dict[str, pd.DataFrame],
    constructed: dict[str, pd.DataFrame],
    agreement: dict[str, pd.DataFrame],
    analysis_dir: Path,
) -> dict[str, pd.DataFrame]:
    """Create reproducible summary tables, figures, and machine-readable metrics."""
    analysis_dir.mkdir(parents=True, exist_ok=True)

    firm = constructed["firm_level_dataset"].copy()
    sentence_corpus = constructed["sentence_corpus"].copy()
    library_matches = constructed["library_matches"].copy()
    oci_candidates = constructed["oci_candidates"].copy()
    direct_primary = cleaned["direct_primary"].copy()
    screened = cleaned["issuer_screened"].copy()

    screening_counts = _series_to_table(screened["decision"].value_counts().sort_index(), "decision", "n_rows")
    screening_counts["share_of_screened_rows"] = screening_counts["n_rows"] / screening_counts["n_rows"].sum()

    disclosure_state_counts = _series_to_table(firm["disclosure_state"].value_counts().sort_index(), "disclosure_state", "n_firms")
    disclosure_state_counts["share_of_firms"] = disclosure_state_counts["n_firms"] / disclosure_state_counts["n_firms"].sum()

    broad_channel_counts = _series_to_table(sentence_corpus["broad_channel"].value_counts().sort_index(), "broad_channel", "n_sentences")
    broad_channel_counts["share_of_sentences"] = broad_channel_counts["n_sentences"] / broad_channel_counts["n_sentences"].sum()

    dataset_channel_counts = (
        sentence_corpus.groupby(["dataset_name", "broad_channel"]).size().rename("n_sentences").reset_index().sort_values(["dataset_name", "n_sentences"], ascending=[True, False])
    )

    python_mentions = (
        sentence_corpus.groupby(["dataset_name", "broad_channel"])["has_python"].sum().rename("python_sentence_count").reset_index().sort_values(["python_sentence_count", "dataset_name"], ascending=[False, True])
    )

    direct_source_type_counts = _series_to_table(direct_primary["source_type"].value_counts().sort_values(ascending=False), "source_type", "n_rows")

    library_dimension_summary = (
        library_matches.groupby("dimension")
        .agg(n_matches=("library_name", "size"), n_unique_firms=("ticker", pd.Series.nunique), libraries=("library_name", lambda values: "|".join(sorted(set(values)))) )
        .reset_index()
        .sort_values(["n_matches", "dimension"], ascending=[False, True])
        if not library_matches.empty
        else pd.DataFrame(columns=["dimension", "n_matches", "n_unique_firms", "libraries"])
    )

    named_library_counts = (
        library_matches.groupby("library_name")
        .agg(n_matches=("sentence_id", "size"), n_unique_firms=("ticker", pd.Series.nunique), dimensions=("dimension", lambda values: "|".join(sorted(set(values)))))
        .reset_index()
        .sort_values(["n_matches", "library_name"], ascending=[False, True])
        if not library_matches.empty
        else pd.DataFrame(columns=["library_name", "n_matches", "n_unique_firms", "dimensions"])
    )

    channel_hhi_summary = firm["channel_hhi"].describe().to_frame(name="value").reset_index().rename(columns={"index": "statistic"})
    channel_hhi_summary["measure"] = "channel_hhi"

    intensity_summary = firm["disclosure_intensity_sentences"].describe().to_frame(name="value").reset_index().rename(columns={"index": "statistic"})
    intensity_summary["measure"] = "disclosure_intensity_sentences"

    subsector_state_counts = (
        firm.groupby(["broad_subsector", "disclosure_state"]).size().rename("n_firms").reset_index().sort_values(["broad_subsector", "disclosure_state"])
    )

    n_firms = int(len(firm))
    n_oci_positive_firms = int(firm["any_oci_claim"].sum())
    oci_lower, oci_upper = clopper_pearson_interval(n_oci_positive_firms, n_firms, alpha=0.05)
    oci_one_sided_upper = clopper_pearson_upper(n_oci_positive_firms, n_firms, alpha=0.05)
    oci_summary = pd.DataFrame(
        [
            {
                "n_firms": n_firms,
                "n_oci_positive_firms": n_oci_positive_firms,
                "oci_firm_prevalence": n_oci_positive_firms / n_firms,
                "oci_firm_prevalence_ci_lower_95": oci_lower,
                "oci_firm_prevalence_ci_upper_95": oci_upper,
                "oci_firm_prevalence_one_sided_upper_95": oci_one_sided_upper,
                "n_oci_positive_sentences": int(len(oci_candidates)),
            }
        ]
    )

    core_metrics = {
        "n_included_firms": n_firms,
        "disclosure_state_counts": disclosure_state_counts.set_index("disclosure_state")["n_firms"].to_dict(),
        "python_positive_firms": int(firm["explicit_python_flag"].sum()),
        "oci_positive_firms": n_oci_positive_firms,
        "oci_one_sided_upper_95": oci_one_sided_upper,
        "direct_second_coder_raw_agreement": float(agreement["direct_coder_metrics"].iloc[0]["raw_agreement"]),
        "direct_second_coder_cohen_kappa": float(agreement["direct_coder_metrics"].iloc[0]["cohen_kappa"]),
        "direct_second_coder_gwet_ac1": float(agreement["direct_coder_metrics"].iloc[0]["gwet_ac1"]),
    }

    tables = {
        "table_issuer_screening_counts": screening_counts,
        "table_disclosure_state_counts": disclosure_state_counts,
        "table_broad_channel_counts": broad_channel_counts,
        "table_dataset_channel_counts": dataset_channel_counts,
        "table_python_mentions_by_dataset_channel": python_mentions,
        "table_direct_source_type_counts": direct_source_type_counts,
        "table_library_dimension_summary": library_dimension_summary,
        "table_named_library_counts": named_library_counts,
        "table_channel_hhi_summary": channel_hhi_summary,
        "table_intensity_summary": intensity_summary,
        "table_subsector_state_counts": subsector_state_counts,
        "table_oci_summary": oci_summary,
    }

    for name, table in tables.items():
        table.to_csv(analysis_dir / f"{name}.csv", index=False)

    write_json(core_metrics, analysis_dir / "summary_metrics.json")

    _save_bar_figure(disclosure_state_counts, "disclosure_state", "n_firms", "Firm disclosure states", analysis_dir / "figure_disclosure_states")
    _save_bar_figure(broad_channel_counts, "broad_channel", "n_sentences", "Sentence counts by broad channel", analysis_dir / "figure_broad_channel_counts")
    _save_histogram(firm["channel_hhi"].rename("channel_hhi"), "Channel concentration (HHI)", analysis_dir / "figure_channel_hhi_histogram")

    return tables
