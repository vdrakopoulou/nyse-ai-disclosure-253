from __future__ import annotations

from typing import Any

import pandas as pd

from src.utils import assert_unique, normalize_text, validate_columns


INCLUDED_REQUIRED = [
    "source_row_number",
    "input_ticker",
    "company_name",
    "current_nyse_symbol",
    "current_security_name",
    "decision",
    "primary_reason",
    "broad_subsector",
]

DIRECT_PRIMARY_REQUIRED = [
    "source_row_number",
    "ticker",
    "company_name",
    "current_security_name",
    "broad_subsector",
    "verification_status",
    "direct_company_evidence_sentence",
    "source_type",
    "source_title",
    "source_url",
    "host_type",
    "verification_basis",
    "notes",
]

EMPLOYMENT_REQUIRED = [
    "ticker",
    "company_name",
    "current_nyse_symbol",
    "broad_subsector",
    "status",
    "evidence_sentence",
    "source_url",
    "source_type",
    "capture_method",
    "ref_id",
    "direct_candidate_in_corpus",
]

DIRECT_SECOND_REQUIRED = [
    "Original Row",
    "Ticker",
    "Company Name",
    "Current Security Name",
    "Broad Subsector",
    "Package Status",
    "Direct Company Evidence Sentence",
    "Source Type",
    "Source Title",
    "Source URL",
    "Host Type",
    "Verification Basis",
    "Notes",
]

FILING_SECOND_VERIFIED_REQUIRED = [
    "symbol",
    "company_name",
    "source_title",
    "source_url",
    "evidence_sentence",
]

FILING_SECOND_UNRESOLVED_REQUIRED = [
    "source_row_number",
    "input_ticker",
    "company_name",
    "current_nyse_symbol",
    "current_security_name",
    "broad_subsector",
]


def _clean_kv_sheet(df: pd.DataFrame) -> pd.DataFrame:
    cleaned = df.copy()
    cleaned.columns = [normalize_text(column) for column in cleaned.columns]
    return cleaned


def clean_included_issuers(raw: pd.DataFrame) -> pd.DataFrame:
    """Standardize the included issuer frame."""
    validate_columns(raw, INCLUDED_REQUIRED, "issuer_included")
    df = raw.copy()
    df = df.rename(
        columns={
            "current_nyse_symbol": "ticker",
            "input_ticker": "input_ticker",
        }
    )
    df["ticker"] = df["ticker"].map(normalize_text)
    df["company_name"] = df["company_name"].map(normalize_text)
    df["current_security_name"] = df["current_security_name"].map(normalize_text)
    df["broad_subsector"] = df["broad_subsector"].map(normalize_text)
    df["decision"] = df["decision"].map(normalize_text)
    assert_unique(df, ["ticker"], "issuer_included")
    assert_unique(df, ["source_row_number"], "issuer_included")
    return df


def clean_screening_frames(raw_data: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
    screened = raw_data["issuer_screened"].copy()
    included = clean_included_issuers(raw_data["issuer_included"])
    excluded = raw_data["issuer_excluded"].copy()
    duplicates = raw_data["issuer_duplicates"].copy()

    for name, frame in {
        "issuer_screened": screened,
        "issuer_excluded": excluded,
    }.items():
        validate_columns(frame, INCLUDED_REQUIRED, name)
        frame["current_nyse_symbol"] = frame["current_nyse_symbol"].map(normalize_text)
        frame["company_name"] = frame["company_name"].map(normalize_text)
        frame["decision"] = frame["decision"].map(normalize_text)

    if not duplicates.empty:
        validate_columns(duplicates, ["firm_id", "company_name", "retained_source_row", "duplicate_source_row"], "issuer_duplicates")

    return {
        "issuer_screened": screened,
        "issuer_included": included,
        "issuer_excluded": excluded,
        "issuer_duplicates": duplicates,
    }


def clean_direct_primary(raw: pd.DataFrame) -> pd.DataFrame:
    """Standardize the primary direct-evidence file."""
    validate_columns(raw, DIRECT_PRIMARY_REQUIRED, "direct_primary")
    df = raw.copy().rename(
        columns={
            "direct_company_evidence_sentence": "sentence_text",
        }
    )
    df["ticker"] = df["ticker"].map(normalize_text)
    df["company_name"] = df["company_name"].map(normalize_text)
    df["current_security_name"] = df["current_security_name"].map(normalize_text)
    df["broad_subsector"] = df["broad_subsector"].map(normalize_text)
    df["verification_status"] = df["verification_status"].map(normalize_text)
    df["sentence_text"] = df["sentence_text"].map(normalize_text)
    df["source_type"] = df["source_type"].map(normalize_text)
    df["source_title"] = df["source_title"].map(normalize_text)
    df["source_url"] = df["source_url"].map(normalize_text)
    df["host_type"] = df["host_type"].map(normalize_text)
    df["verification_basis"] = df["verification_basis"].map(normalize_text)
    df["notes"] = df["notes"].map(normalize_text)
    df["direct_status_binary"] = df["verification_status"].map(
        {
            "verified_direct_sentence": "verified",
            "pending_direct_verification": "unresolved",
            "closed_no_strict_direct_match": "unresolved",
        }
    )
    df["has_sentence"] = df["sentence_text"] != ""
    assert_unique(df, ["ticker"], "direct_primary")
    assert_unique(df, ["source_row_number"], "direct_primary")
    return df


def clean_employment_materials(raw: pd.DataFrame) -> pd.DataFrame:
    """Standardize the employment and technical-materials evidence file."""
    validate_columns(raw, EMPLOYMENT_REQUIRED, "employment_materials")
    df = raw.copy().rename(columns={"evidence_sentence": "sentence_text"})
    text_columns = [
        "ticker",
        "company_name",
        "current_nyse_symbol",
        "broad_subsector",
        "status",
        "sentence_text",
        "source_url",
        "source_type",
        "capture_method",
        "ref_id",
        "donor_company_name",
        "donor_source_type",
        "reviewed_new_url",
        "unresolved_reason",
    ]
    for column in text_columns:
        if column in df.columns:
            df[column] = df[column].map(normalize_text)
    df["status"] = df["status"].str.lower()
    df["has_sentence"] = df["sentence_text"] != ""
    assert_unique(df, ["ticker"], "employment_materials")
    return df


def clean_direct_second_coder(verified: pd.DataFrame, unresolved: pd.DataFrame) -> pd.DataFrame:
    """Standardize and stack the second-coder direct evidence workbook."""
    validate_columns(verified, DIRECT_SECOND_REQUIRED, "direct_second_verified")
    validate_columns(unresolved, DIRECT_SECOND_REQUIRED, "direct_second_unresolved")
    df = pd.concat([verified.copy(), unresolved.copy()], ignore_index=True)
    df = df.rename(
        columns={
            "Original Row": "source_row_number",
            "Ticker": "ticker",
            "Company Name": "company_name",
            "Current Security Name": "current_security_name",
            "Broad Subsector": "broad_subsector",
            "Package Status": "package_status",
            "Direct Company Evidence Sentence": "sentence_text",
            "Source Type": "source_type",
            "Source Title": "source_title",
            "Source URL": "source_url",
            "Host Type": "host_type",
            "Verification Basis": "verification_basis",
            "Notes": "notes",
        }
    )
    for column in df.columns:
        if column != "source_row_number":
            df[column] = df[column].map(normalize_text)
    df["direct_second_status_binary"] = df["package_status"].str.casefold().map(
        {
            "verified direct sentence": "verified",
            "unresolved": "unresolved",
        }
    )
    assert_unique(df, ["ticker"], "direct_second_coder")
    assert_unique(df, ["source_row_number"], "direct_second_coder")
    return df


def clean_filing_second_coder(verified: pd.DataFrame, unresolved: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Standardize the second-coder filing audit workbook."""
    validate_columns(verified, FILING_SECOND_VERIFIED_REQUIRED, "filing_second_verified")
    validate_columns(unresolved, FILING_SECOND_UNRESOLVED_REQUIRED, "filing_second_unresolved")

    verified_df = verified.copy().rename(columns={"symbol": "ticker", "evidence_sentence": "sentence_text"})
    unresolved_df = unresolved.copy().rename(columns={"current_nyse_symbol": "ticker"})

    for column in verified_df.columns:
        verified_df[column] = verified_df[column].map(normalize_text)
    for column in unresolved_df.columns:
        unresolved_df[column] = unresolved_df[column].map(normalize_text)

    verified_df["filing_second_status_binary"] = "verified"
    unresolved_df["filing_second_status_binary"] = "unresolved"

    assert_unique(verified_df, ["ticker"], "filing_second_verified")
    assert_unique(unresolved_df, ["ticker"], "filing_second_unresolved")

    combined = pd.concat(
        [
            verified_df[["ticker", "company_name", "filing_second_status_binary"]],
            unresolved_df[["ticker", "company_name", "filing_second_status_binary"]],
        ],
        ignore_index=True,
    )
    assert_unique(combined, ["ticker"], "filing_second_combined")

    return {
        "filing_second_verified": verified_df,
        "filing_second_unresolved": unresolved_df,
        "filing_second_combined": combined,
    }


def extract_workbook_notes(raw_data: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Capture workbook-level metadata and known internal inconsistencies."""
    notes: list[dict[str, Any]] = []
    direct_summary = _clean_kv_sheet(raw_data["direct_summary"])
    direct_readme = raw_data["direct_readme"].copy()

    summary_pairs = {}
    if {"Metric", "Value"}.issubset(direct_summary.columns):
        summary_pairs = dict(zip(direct_summary["Metric"].map(normalize_text), direct_summary["Value"]))

    readme_pairs = {}
    if {"Field", "Explanation"}.issubset(direct_readme.columns):
        readme_pairs = dict(zip(direct_readme["Field"].map(normalize_text), direct_readme["Explanation"].map(normalize_text)))

    if summary_pairs:
        notes.append(
            {
                "note_type": "direct_summary_metrics",
                "field": "verified_direct_company_matched_sentences_completed",
                "value": summary_pairs.get("Verified direct company-matched sentences completed", ""),
                "message": "Value read from the direct-evidence Summary sheet.",
            }
        )
        notes.append(
            {
                "note_type": "direct_summary_metrics",
                "field": "closed_unresolved_under_strict_direct_match_standard",
                "value": summary_pairs.get("Closed unresolved under strict direct-match standard", ""),
                "message": "Value read from the direct-evidence Summary sheet.",
            }
        )

    if readme_pairs:
        notes.append(
            {
                "note_type": "direct_readme_result",
                "field": "result",
                "value": readme_pairs.get("Result", ""),
                "message": "This README row conflicts with the All_253_Status and Summary sheets and appears to be stale.",
            }
        )

    notes.append(
        {
            "note_type": "sample_scope_conflict",
            "field": "included_issuers_in_uploaded_data",
            "value": 253,
            "message": "Uploaded data consistently support a 253-firm included issuer sample, not the 546-firm figure referenced in the user-supplied abstract.",
        }
    )

    return pd.DataFrame(notes)


def clean_all(raw_data: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
    """Produce all cleaned datasets used by the replication pipeline."""
    screening = clean_screening_frames(raw_data)
    direct_primary = clean_direct_primary(raw_data["direct_primary"])
    employment = clean_employment_materials(raw_data["employment_materials"])
    direct_second = clean_direct_second_coder(raw_data["direct_second_verified"], raw_data["direct_second_unresolved"])
    filing_second = clean_filing_second_coder(raw_data["filing_second_verified"], raw_data["filing_second_unresolved"])
    workbook_notes = extract_workbook_notes(raw_data)

    return {
        **screening,
        "employment_materials": employment,
        "direct_primary": direct_primary,
        "direct_second_coder": direct_second,
        **filing_second,
        "workbook_notes": workbook_notes,
    }
