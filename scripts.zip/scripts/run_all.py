from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.analysis import create_analysis_outputs
from src.clean_data import clean_all
from src.coder_agreement import coder_agreement_all
from src.construct_variables import construct_all
from src.load_data import load_raw_data
from src.utils import ensure_dirs, read_yaml, setup_logging


def _save_frames(frames: dict[str, pd.DataFrame], directory: Path, logger_name: str) -> None:
    for name, frame in frames.items():
        output_path = directory / f"{name}.csv"
        frame.to_csv(output_path, index=False)


def main() -> None:
    config_path = PROJECT_ROOT / "config.yaml"
    config = read_yaml(config_path)

    np.random.seed(config["project"]["random_seed"])

    output_root = PROJECT_ROOT / config["paths"]["outputs"]
    log_root = PROJECT_ROOT / config["paths"]["logs"]
    clean_dir = PROJECT_ROOT / config["outputs"]["clean_dir"]
    constructed_dir = PROJECT_ROOT / config["outputs"]["constructed_dir"]
    agreement_dir = PROJECT_ROOT / config["outputs"]["agreement_dir"]
    analysis_dir = PROJECT_ROOT / config["outputs"]["analysis_dir"]

    ensure_dirs([output_root, log_root, clean_dir, constructed_dir, agreement_dir, analysis_dir])
    logger = setup_logging(log_root)

    logger.info("Loading raw data.")
    raw_data = load_raw_data(PROJECT_ROOT, config)

    logger.info("Cleaning and validating inputs.")
    cleaned = clean_all(raw_data)
    _save_frames(cleaned, clean_dir, "clean")

    logger.info("Constructing sentence-level and firm-level variables.")
    constructed = construct_all(cleaned, config)
    _save_frames(constructed, constructed_dir, "constructed")

    logger.info("Computing coder agreement and disagreement outputs.")
    agreement = coder_agreement_all(cleaned, config)
    _save_frames(agreement, agreement_dir, "agreement")

    logger.info("Producing summary tables and figures.")
    create_analysis_outputs(cleaned, constructed, agreement, analysis_dir)

    manifest = pd.DataFrame(
        {
            "stage": ["clean", "construct", "agreement", "analysis"],
            "output_directory": [str(clean_dir.relative_to(PROJECT_ROOT)), str(constructed_dir.relative_to(PROJECT_ROOT)), str(agreement_dir.relative_to(PROJECT_ROOT)), str(analysis_dir.relative_to(PROJECT_ROOT))],
        }
    )
    manifest.to_csv(output_root / "output_manifest.csv", index=False)

    logger.info("Replication pipeline completed successfully.")


if __name__ == "__main__":
    main()
