from __future__ import annotations

import pandas as pd

from src.construct_variables import build_firm_level_dataset, flag_oci


def test_flag_oci_detects_quantified_ai_outcome() -> None:
    config = {
        "analysis": {
            "ai_regex": r"(?i)(artificial intelligence|\bai\b|machine learning|generative ai|genai|chatgpt|large language model|\bllm\b|automation)",
            "python_regex": r"(?i)\bpython\b",
            "oci_outcome_regex": r"(?i)(underwriting|efficiency|performance|risk)",
            "oci_quant_regex": r"(?i)(\b\d+(?:\.\d+)?\s?(?:seconds?|days?)\b)",
            "oci_claim_verb_regex": r"(?i)(accelerat|improv|reduc|from\s+\d+(?:\.\d+)?\s?\w+\s+to\s+\d+(?:\.\d+)?\s?\w+)",
        }
    }
    sentence = "The insurer used artificial intelligence to accelerate underwriting from 22 days to 22 seconds."
    assert flag_oci(sentence, config) is True


def test_build_firm_level_dataset_prioritizes_python() -> None:
    cleaned = {
        "issuer_included": pd.DataFrame(
            {
                "source_row_number": [1, 2],
                "ticker": ["AAA", "BBB"],
                "company_name": ["Firm A", "Firm B"],
                "current_security_name": ["Firm A Common", "Firm B Common"],
                "broad_subsector": ["Banking", "Insurance"],
                "decision": ["Include", "Include"],
                "primary_reason": ["Operating financial issuer", "Operating financial issuer"],
            }
        ),
        "direct_primary": pd.DataFrame(
            {
                "ticker": ["AAA", "BBB"],
                "direct_status_binary": ["verified", "unresolved"],
            }
        ),
        "employment_materials": pd.DataFrame(
            {
                "ticker": ["AAA", "BBB"],
                "status": ["verified", "verified"],
            }
        ),
    }
    sentence_corpus = pd.DataFrame(
        {
            "ticker": ["AAA", "BBB"],
            "broad_channel": ["employment_materials", "corporate_communications"],
            "has_python": [True, False],
            "oci_flag": [False, False],
        }
    )
    library_matches = pd.DataFrame(
        {
            "ticker": ["AAA"],
            "library_name": ["plotly"],
            "dimension": ["visualization"],
        }
    )
    result = build_firm_level_dataset(cleaned, sentence_corpus, library_matches)
    states = dict(zip(result["ticker"], result["disclosure_state"]))
    assert states["AAA"] == "explicit_python"
    assert states["BBB"] == "indirect_ai"
