from __future__ import annotations

from src.utils import clopper_pearson_upper, compute_channel_hhi, gwet_ac1


def test_compute_channel_hhi_half_half() -> None:
    assert compute_channel_hhi([1, 1]) == 0.5


def test_clopper_pearson_upper_zero_successes() -> None:
    upper = clopper_pearson_upper(0, 10, alpha=0.05)
    assert 0.25 < upper < 0.35


def test_gwet_ac1_perfect_agreement() -> None:
    value = gwet_ac1(["verified", "verified", "unresolved"], ["verified", "verified", "unresolved"])
    assert value == 1.0
