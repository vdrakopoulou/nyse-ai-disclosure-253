from __future__ import annotations

import pandas as pd

from src.coder_agreement import summarize_direct_agreement


def test_summarize_direct_agreement_returns_expected_counts() -> None:
    merged = pd.DataFrame(
        {
            "direct_status_binary": ["verified", "verified", "unresolved"],
            "direct_second_status_binary": ["verified", "unresolved", "unresolved"],
            "status_agreement": [True, False, True],
            "exact_url_match": [True, False, True],
            "exact_sentence_match": [False, False, True],
            "same_domain": [True, False, True],
            "same_broad_channel": [True, False, True],
            "disagreement_type": ["both_verified_sentence_variant", "status_disagreement", "agreement"],
            "source_row_number": [1, 2, 3],
            "ticker": ["AAA", "BBB", "CCC"],
            "company_name_primary": ["Firm A", "Firm B", "Firm C"],
            "primary_broad_channel": ["filings_formal_reports", "press_and_news", "employment_materials"],
            "second_broad_channel": ["filings_formal_reports", "corporate_communications", "employment_materials"],
            "primary_domain": ["a.com", "b.com", "c.com"],
            "second_domain": ["a.com", "x.com", "c.com"],
            "source_type_primary": ["Annual report", "Press release", "Employment material"],
            "source_type_second": ["Annual report", "Official page", "Employment material"],
            "source_title_primary": ["A", "B", "C"],
            "source_title_second": ["A2", "B2", "C2"],
            "source_url_primary": ["https://a.com", "https://b.com", "https://c.com"],
            "source_url_second": ["https://a.com", "https://x.com", "https://c.com"],
            "sentence_text_primary": ["p1", "p2", "p3"],
            "sentence_text_second": ["s1", "s2", "s3"],
            "notes_primary": ["", "", ""],
            "notes_second": ["", "", ""],
        }
    )
    confusion, metrics, disagreement_log = summarize_direct_agreement(merged)
    assert int(metrics.loc[0, "n_units"]) == 3
    assert int(metrics.loc[0, "n_status_disagreements"]) == 1
    assert len(disagreement_log) == 1
    assert confusion["verified"].sum() + confusion["unresolved"].sum() == 3
